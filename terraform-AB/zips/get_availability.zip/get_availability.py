import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Availability')

def lambda_handler(event, context):
    try:
        body = json.loads(event['body'])
        scooter_id = body.get('scooterId')
        date = body.get('date')

        if not scooter_id or not date:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Missing parameters'})
            }

        response = table.get_item(
            Key={'scooterId': scooter_id, 'date': date}
        )

        item = response.get('Item', {})

        return {
            'statusCode': 200,
            'body': json.dumps(item)
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
