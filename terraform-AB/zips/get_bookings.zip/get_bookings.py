import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Bookings')

def lambda_handler(event, context):
    try:
        response = table.scan()
        bookings = response.get('Items', [])

        return {
            'statusCode': 200,
            'body': json.dumps({'bookings': bookings})
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
